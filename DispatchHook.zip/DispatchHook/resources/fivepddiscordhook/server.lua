-- Please enter your Discord Webhook here!
-- More information here if you need help >> https://support.discord.com/hc/en-us/articles/228383668-Intro-to-Webhooks
local webhookURL = "PLEASE_CHANGE_ME_PRETTY_PLEASE"

--This gets called from the plugin when you accept a callout
RegisterNetEvent('calloutAcceptedDiscord')
AddEventHandler('calloutAcceptedDiscord', function(callName, callCode, callRespond)
    
    --Everything here is configurable!
    local embed = {
        ["title"] = "🚨 Dispatch 🚨",
        ["description"] = "An officer is responding...",
        ["color"] = 16711680,  -- Red color
        ["fields"] = {
            {
                ["name"] = "**Description**",
                ["value"] = callName, --Dont Change!
                ["inline"] = true
            },
            {
                ["name"] = "**Responce Code**",
                ["value"] = callCode, --Dont Change!
                ["inline"] = true
            },
            {
                ["name"] = "**Officer Responding**",
                ["value"] = callRespond, --Dont Change!
                ["inline"] = true
            }
        },
        ["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ")
    }

    local jsonData = {
        ["content"] = "New Information",  -- Changable but can't be empty
        ["username"] = "Dispatch", --Bot "Name"
        ["avatar_url"] = "https://www.stickershoppe.com/mm5/graphics/00000001/827-3046.jpg", -- Replace with your image URL
        ["embeds"] = {embed}  -- Embeds MUST be in an array
    }

    --Non-Configurable from this point on!
    local jsonMessage = json.encode(jsonData)

    PerformHttpRequest(webhookURL, function(statusCode, response, headers)
        if statusCode == 204 then
            print("✅ Successfully sent message to Discord!")
        else
            print("❌ Failed to send message to Discord. Status Code: " .. statusCode)
            print("Response: " .. tostring(response)) -- Print response for debugging
        end
    end, "POST", jsonMessage, { ["Content-Type"] = "application/json" })
end)