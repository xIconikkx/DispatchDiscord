fx_version 'cerulean'
game 'gta5'

-- Define server-side scripts
server_scripts {
    'server.lua'      -- Your Lua server-side script
}

-- Made by ChadF
-- Please do not reupload without permission
-- Contact me for anymore changes/additions